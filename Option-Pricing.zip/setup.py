from setuptools import setup

setup(name='option_pricing',
      version='0.0.1',
      description='An package for option pricing.',
      author='Yicheng Wang',
      author_email='wangy8989@homail.com',
      packages=['option_pricing'],
      install_requires=['scipy',
                        'numpy'])